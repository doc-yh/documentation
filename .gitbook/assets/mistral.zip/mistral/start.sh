#!/bin/sh
pip install poetry
poetry update package
poetry run python mistral.py